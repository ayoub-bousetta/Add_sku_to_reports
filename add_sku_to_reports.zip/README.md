## About the Plugin

A WooCommerce Admin Extension to add sku(s) to the analytics table reports woocommerce (Analytics -> Orders)

## Screenshots.

<b>Analytics -> Orders</b>

![Orders Page](https://i.imgur.com/b6hVqDi.png)


## Non developers

<ol>
  <li>Donload from here<</li>
  <li><p>Navigate to Admin -> Plugins -> Add new -> Upload the .zip -> Activate the plugin </p></li>

</ol>


## Credits.

<dl>
  <dt>Ayoub Bousetta</dt>
  <dd><a href="https://abusta.com">abusta.com</a></dd>

</dl>


